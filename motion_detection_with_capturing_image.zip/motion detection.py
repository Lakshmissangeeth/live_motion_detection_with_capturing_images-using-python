import cv2
import numpy as np
import time
import os

# Create a directory to save captured frames if it doesn't exist
if not os.path.exists("captured_frames"):
    os.makedirs("captured_frames")

# Open webcam
cap = cv2.VideoCapture(0)

# Read the first frame for background subtraction
ret, frame1 = cap.read()
gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
gray1 = cv2.GaussianBlur(gray1, (21, 21), 0)

frame_count = 0  # To count saved frames

while True:
    # Read next frame
    ret, frame2 = cap.read()
    if not ret:
        break
    
    # Convert frame to grayscale and blur it
    gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.GaussianBlur(gray2, (21, 21), 0)
    
    # Compute absolute difference between frames
    diff = cv2.absdiff(gray1, gray2)
    
    # Apply threshold to detect changes
    _, thresh = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)
    
    # Dilate the threshold image to fill in holes
    thresh = cv2.dilate(thresh, None, iterations=2)
    
    # Find contours of moving objects
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    motion_detected = False
    
    for contour in contours:
        if cv2.contourArea(contour) < 500:  # Ignore small movements
            continue

        motion_detected = True

        # Get bounding box and draw rectangle
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(frame2, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Capture the frame if motion is detected
    if motion_detected:
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"captured_frames/motion_{timestamp}_{frame_count}.jpg"
        cv2.imwrite(filename, frame2)
        print(f"Captured: {filename}")
        frame_count += 1

    # Show video
    cv2.imshow("Motion Detection", frame2)
    
    # Update previous frame
    gray1 = gray2.copy()
    
    # Press 'q' to exit
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
