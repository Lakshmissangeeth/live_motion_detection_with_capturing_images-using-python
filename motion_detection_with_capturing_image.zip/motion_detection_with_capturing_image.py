import cv2
import numpy as np
import time
import os

# Create a directory to save captured images
save_dir = "captured_frames"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# Open webcam
cap = cv2.VideoCapture(0)

# Read the first frame
ret, frame1 = cap.read()
gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
gray1 = cv2.GaussianBlur(gray1, (21, 21), 0)

while True:
    # Read the next frame
    ret, frame2 = cap.read()
    if not ret:
        break

    # Convert to grayscale and apply blur
    gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.GaussianBlur(gray2, (21, 21), 0)

    # Compute absolute difference between current frame and previous frame
    diff = cv2.absdiff(gray1, gray2)

    # Apply threshold and dilation
    _, thresh = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)
    thresh = cv2.dilate(thresh, None, iterations=2)

    # Find contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    motion_detected = False

    for contour in contours:
        if cv2.contourArea(contour) < 500:
            continue

        motion_detected = True
        # Draw bounding box
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(frame2, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # If motion is detected, save the frame as image
    if motion_detected:
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"{save_dir}/motion_{timestamp}.jpg"
        cv2.imwrite(filename, frame2)
        print(f"[INFO] Motion detected. Image saved as: {filename}")

    # Show the video frame
    cv2.imshow("Motion Detection", frame2)

    # Update previous frame
    gray1 = gray2.copy()

    # Press 'q' to quit
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break

# Cleanup
cap.release()
cv2.destroyAllWindows()
